"use client"

// Zde umístěte pouze funkce, které potřebujete na klientské straně
// a nepoužívají Node.js moduly jako fs a path

